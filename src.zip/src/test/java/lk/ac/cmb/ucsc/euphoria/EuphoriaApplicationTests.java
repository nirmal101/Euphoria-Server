package lk.ac.cmb.ucsc.euphoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EuphoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
