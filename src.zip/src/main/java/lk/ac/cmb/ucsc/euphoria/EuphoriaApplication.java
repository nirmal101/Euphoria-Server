package lk.ac.cmb.ucsc.euphoria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EuphoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EuphoriaApplication.class, args);
	}

}
